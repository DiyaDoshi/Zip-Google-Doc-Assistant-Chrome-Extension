// background.js
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "sendMessage") {
        fetch("https://doc-assistant-166x.onrender.com/chat", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                message: request.message,
                doc_url: request.doc_url,
                conversation_id: request.conversation_id
            })
        })
        .then(response => response.json())
        .then(data => sendResponse({ response: data.response }))
        .catch(error => sendResponse({ response: "Error: " + error.message }));
        return true; // Will respond asynchronously
    } else if (request.action === "openPopup") {
        console.log("Received doc_url:", request.doc_url); // Debugging log
        chrome.windows.create({
    
            url: chrome.runtime.getURL("popup.html") + `?doc_url=${encodeURIComponent(request.doc_url)}`, // Pass doc_url as a query parameter
            type: "popup",
            width: 400,
            height: 600
        });
    }
});
