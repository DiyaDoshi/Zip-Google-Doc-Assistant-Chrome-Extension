// content.js
(function() {
    // Create a floating button to open the popup
    // const openPopupButton = document.createElement('button');
    // openPopupButton.innerText = 'DA';
    // openPopupButton.style.position = 'fixed';
    // openPopupButton.style.bottom = '500px';
    // openPopupButton.style.right = '1px';
    // openPopupButton.style.zIndex = '1000';
    // openPopupButton.style.padding = '10px';
    // openPopupButton.style.backgroundColor = '#4285f4';
    // openPopupButton.style.color = 'white';
    // openPopupButton.style.border = 'none';
    // openPopupButton.style.borderRadius = '5px';
    // openPopupButton.style.cursor = 'pointer';

    let button = document.createElement("button");


    button.classList.add("extension-button");

    // Create an image element
    let iconImage = document.createElement("img");
    iconImage.src = chrome.runtime.getURL("icons/doc.svg"); // Correct path
    iconImage.alt = "Gmail Assistant";

    // Append the image inside the button
    button.appendChild(iconImage);

    // Apply styles to button
    button.style.position = "fixed";
    button.style.bottom = "5px";
    button.style.right = "5px";
    button.style.zIndex = "1000";
    button.style.border = "none";
    button.style.background = "transparent";
    button.style.padding = "0";
    button.style.cursor = "pointer";

    // Apply styles to image
    iconImage.style.width = "30px";
    iconImage.style.height = "30px";
    iconImage.style.backgroundColor = "#ebccff";
    iconImage.style.borderRadius = "50%";
    iconImage.style.padding = "9px";
    iconImage.style.objectFit = "contain";
    iconImage.style.boxShadow = "0 4px 6px rgba(0, 0, 0, 0.1)";
    iconImage.style.transition = "background-color 0.3s ease, transform 0.3s ease";

    document.body.appendChild(button);

    // Add event listener to the button
    button.addEventListener('click', () => {
        const doc_url = window.location.href; // Get the current URL of the Google Doc
        console.log("Extracted doc_url:", doc_url); // Debugging log
        chrome.runtime.sendMessage({ action: 'openPopup' , doc_url });
    });

    
})();
