import os
import logging
import requests
from fastapi import FastAPI
from pydantic import BaseModel
from dotenv import load_dotenv
from fastapi.middleware.cors import CORSMiddleware
from typing import Optional
from langchain_chroma import Chroma
from langchain_google_genai import ChatGoogleGenerativeAI, GoogleGenerativeAIEmbeddings

# Load environment variables
load_dotenv()

# Initialize FastAPI app
app = FastAPI()
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Change to specific domains if needed
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configuration
CHROMA_PATH = "chroma_db"

google_embeddings = GoogleGenerativeAIEmbeddings(model="models/embedding-001")
llm = ChatGoogleGenerativeAI(model="gemini-1.5-pro", temperature=1.0)

# Connect to ChromaDB
vector_store = Chroma(
    collection_name="docs_chat",
    embedding_function=google_embeddings,
    persist_directory=CHROMA_PATH,
)
retriever = vector_store.as_retriever(search_kwargs={'k': 5})

# Define data models
class ChatRequest(BaseModel):
    message: str
    doc_url: str
    conversation_id: Optional[str] = None

class Message(BaseModel):
    role: str  # "user" or "assistant"
    content: str
    timestamp: Optional[str] = None

class Conversation(BaseModel):
    messages: list[Message] = []

conversation_memory = {}  # Store conversation history per document

@app.post("/chat")
async def chat_with_document(data: ChatRequest):
    doc_id = data.doc_url.split("/d/")[1].split("/")[0]  # Extract Google Doc ID
    if doc_id not in conversation_memory:
        conversation_memory[doc_id] = Conversation(messages=[])

    conversation = conversation_memory[doc_id]
    conversation.messages.append(Message(role="user", content=data.message))

    # Fetch the content from the Google Docs URL
    response = requests.get(data.doc_url)
    if response.status_code == 200:
        knowledge = response.text
    else:
        knowledge = "Could not retrieve document content."

    prompt_template = """
    You are an AI assistant that helps users interact with their Google Docs.
    The user is referring to a document with ID: {doc_id}.
    Use the content retrieved from the document and past conversation context to respond.

    Document Content:
    {knowledge}

    Previous Conversation:
    {previous_conversation}

    User Message:
    {user_message}
    """

    previous_conversation = '\n'.join([f'{msg.role}: {msg.content}' for msg in conversation.messages[-5:]])
    prompt = prompt_template.format(
        doc_id=doc_id,
        knowledge=knowledge,
        previous_conversation=previous_conversation,
        user_message=data.message
    )

    response = ""
    for chunk in llm.stream(prompt):
        if chunk.content:
            response += chunk.content

    conversation.messages.append(Message(role="assistant", content=response))
    return {"response": response if response else "No AI response generated."}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8080)

