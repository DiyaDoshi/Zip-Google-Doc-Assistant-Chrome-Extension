// Auto-resize textarea as user types
const messageInput = document.getElementById("message");
messageInput.addEventListener("input", function() {
    this.style.height = "24px";
    this.style.height = (this.scrollHeight) + "px";
});

// Send message on Enter key (Shift+Enter for new line)
messageInput.addEventListener("keydown", function(event) {
    if (event.key === "Enter" && !event.shiftKey) {
        event.preventDefault();
        document.getElementById("send").click();
    }
});

document.getElementById("send").addEventListener("click", () => {
    const message = document.getElementById("message").value.trim();
    // const doc_url = "https://docs.google.com/document/d/e/2PACX-1vSuHp1u31VEl8M6ROv3R6o3Nmb2QBPm3BPqFD6JscD7w1sdPQy9yoZL7fbl1cgrvfS8XJV80VBraPz7/pub"; // Hardcoded doc URL
    // Get the doc_url from the query parameters
    const urlParams = new URLSearchParams(window.location.search);
    const doc_url = urlParams.get("doc_url");

    if (!message || !doc_url) return;
    // if (!message) return;

    // Add user message to chat UI
    addMessage(message, "user-message");
    
    // Reset textarea height
    const messageInput = document.getElementById("message");
    messageInput.value = "";
    messageInput.style.height = "24px";
    
    // Show typing indicator
    const typingIndicator = document.createElement("div");
    typingIndicator.classList.add("typing-indicator");
    typingIndicator.innerHTML = `
        <div class="typing-dot"></div>
        <div class="typing-dot"></div>
        <div class="typing-dot"></div>
    `;
    document.getElementById("chat-box").appendChild(typingIndicator);
    scrollToBottom();

    // Send message to the background script
    chrome.runtime.sendMessage({ action: "sendMessage", message: message, doc_url: doc_url }, (response) => {
        // Remove typing indicator
        typingIndicator.remove();
        
        // Add bot response to chat UI
        addMessage(response.response, "bot-message");
    });
});

function addMessage(text, className) {
    const chatBox = document.getElementById("chat-box");
    const messageElement = document.createElement("div");
    messageElement.classList.add("message", className);
    
    // Handle message formatting (convert URLs to links, preserve line breaks)
    const formattedText = text
        .replace(/https?:\/\/[^\s]+/g, url => `<a href="${url}" target="_blank">${url}</a>`)
        .replace(/\n/g, "<br>");
    
    messageElement.innerHTML = formattedText;
    chatBox.appendChild(messageElement);
    
    scrollToBottom();
}

function scrollToBottom() {
    const chatBox = document.getElementById("chat-box");
    chatBox.scrollTop = chatBox.scrollHeight;
}

// Initialize the chat with a welcome message
window.addEventListener("DOMContentLoaded", () => {
    setTimeout(() => {
        addMessage("Hello! I'm your Google Docs assistant. Ask me anything about your document.", "bot-message");
    }, 500);
});
